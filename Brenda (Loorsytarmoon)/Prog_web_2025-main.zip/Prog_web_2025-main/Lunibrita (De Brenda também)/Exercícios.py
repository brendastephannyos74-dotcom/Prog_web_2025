idade = int(input(20))
if idade <= 18:
    print("ele é maio de idade")

nota = float(input(7))

if nota <= 9:
    "(print = aprovado)"

if nota >= 8:
   "(print = boa)"

"(print = presisa melhora)"

temperatura = int(input <= 14)

if temperatura >= 15:
    print("Frio se menor")

if temperatura > 15 and temperatura < 25:
    print("Agradável se entre")

if temperatura <= 25 :
    print("Quente se acima")

consumo = float(input(100))

if consumo < 100:
  print("baixo")

if consumo > 100 and consumo < 200:
   print ("modersdo")

if consumo < 200:
    print("alto")