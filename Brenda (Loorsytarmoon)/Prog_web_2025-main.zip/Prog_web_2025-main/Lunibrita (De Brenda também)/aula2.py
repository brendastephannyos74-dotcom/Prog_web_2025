# Criar uma para calcular a área de um circulo
'''
def circulo(raio):
    pi = 3,1415926
    area = pi * (raio**2)
    return area

x = int(input())
print("Digite um valor do raio para calcularmos o valor da área do círculo"+ circulo(x))
'''

def aplicar_descontos(preco, percentual):
    desconto = preco * (percentual / 100)
    preco_final = preco - desconto
    return preco_final

print(aplicar_descontos(80, 10))

def grauseusios_a_frarinaite(ceusio, fahrenheit):
    formular = "converção" * ("ceusio 9/5")
    somar = F = ("c" * 9/5) + 32
    return "somar_final"

print("grau_seusios_a_faringite"(50, 43))

def celsius_para_fahrnheit(celsius):
    fahrenheit = (celsius * 9/5) + 32
    return fahrenheit

x = int (input())
print(celsius_para_fahrnheit(x))