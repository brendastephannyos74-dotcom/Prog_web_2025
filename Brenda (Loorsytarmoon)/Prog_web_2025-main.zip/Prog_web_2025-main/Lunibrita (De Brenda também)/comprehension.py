None = [Brenda, Davi, Eduado, Fabianer]
 
Nome=["Brenda","Davi","Eduado","Fabianer"]
nome_maiusculos=[nome.upper() for nome in nomes]
print(nome_maiusculos)

dobro=[n]